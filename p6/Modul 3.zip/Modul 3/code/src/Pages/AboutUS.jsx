const About = () => {
    return(
        <div> 
            <section className="contentAbout">
            <h1>About Us</h1>
            </section>
        </div>
    );
};

export default About