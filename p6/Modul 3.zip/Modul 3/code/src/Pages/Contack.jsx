import Footer from "../Component/Footer";

const Contact = () => {
    return(
        <div> 
            <section className="contentContact">
            <div>
                <h1>Contact Us</h1>
            </div>
            </section>
        </div>
    );
};

export default Contact