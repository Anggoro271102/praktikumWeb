import Hero from "../Component/Hero";


const Home = () => {
    return(
        <div> 
            <Hero/>
            <section className="content">
            </section>
        </div>
    );
};

export default Home