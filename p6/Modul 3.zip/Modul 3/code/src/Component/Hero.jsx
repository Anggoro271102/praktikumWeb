import React from 'react'; // Pastikan Anda mengimpor React

const Hero = () => {
  return (
    <section className="home" >
      <div className="content">
        <h1>Selamat Datang</h1>
        <p>di website Praktikum Pemrograman website</p>
      </div>
    </section>
  );
}

export default Hero;
