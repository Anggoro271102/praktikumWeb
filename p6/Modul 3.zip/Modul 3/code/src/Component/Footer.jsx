import React from 'react'; // Pastikan Anda mengimpor React

import logo_ilab from '../Assets/logo-ilab.png';
import logo_fb from '../Assets/logo-facebook.png';
import logo_twitter from '../Assets/logo-twitter.png';
import logo_ig from '../Assets/logo-instagram.png';


const Footer = () => {
  return (
    <footer className="row row-cols-md-5 my-5">
      <div style={{ marginLeft: '100px', marginRight: '120px' }} className="col mb-3">
        <a href="/" className="col-md-5 col-xs-12 d-flex justify-content-center">
          <img
            style={{ paddingLeft: '150px', paddingTop: '40px' }}
            src={logo_ilab}
            alt="ilab-bawah"
          />
        </a>

        <div className="copyright">
          <p className="text-muted muted" style={{ paddingTop: '80px' }}>
            Copyright &copy; 2022. Infinite Learning
          </p>
        </div>
      </div>

      {/* Head Services */}
      <div className="col">
        <p className="text-secondary">Services</p>
        <ul className="nav flex-column">
          <li className="nav-item mb-2"><a href="#">Email Marketing</a></li>
          <li className="nav-item mb-2"><a href="#">Campaigns</a></li>
          <li className="nav-item mb-2"><a href="#">Branding</a></li>
          <li className="nav-item mb-2"><a href="#">Offline</a></li>
        </ul>
      </div>

      {/* Head About */}
      <div className="col">
        <p className="text-secondary">About</p>
        <ul className="nav flex-column">
          <li className="nav-item mb-2"><a href="#">Our Story</a></li>
          <li className="nav-item mb-2"><a href="#">Benefits</a></li>
          <li className="nav-item mb-2"><a href="#">Team</a></li>
          <li className="nav-item mb-2"><a href="#">Careers</a></li>
        </ul>
      </div>

      {/* Head Follow-Us */}
      <div className="col">
        <p className="text-secondary">Follow Us</p>
        <ul className="nav flex-column">
          <li className="nav-item mb-2">
            <a href="#">
              <img
                src={logo_fb}
                alt="facebook"
                style={{width: '23px', height: '23px'}}
              />
              Facebook
            </a>
          </li>
          <li className="nav-item mb-2">
            <a href="#">
              <img
                src={logo_twitter}
                alt="twitter"
                style={{width: '25px', height: '23px'}}
              />
              Twitter
            </a>
          </li>
          <li className="nav-item mb-2">
            <a href="#">
              <img
                src={logo_ig}
                alt="instagram"
                style={{width: '25px', height: '25px'}}
              />
              Instagram
            </a>
          </li>
        </ul>
      </div>
    </footer>
  );
}

export default Footer;
