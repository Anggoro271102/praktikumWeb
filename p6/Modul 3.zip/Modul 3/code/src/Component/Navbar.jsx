import 'bootstrap/dist/css/bootstrap.min.css';
import logo_ilab from '../Assets/logo-ilab.png';
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary">
        
      <div className="container-fluid">
        <Link to="/" className="navbar-brand">
          <img
            src={logo_ilab}
            alt="ilab"
            width="58"
            height="25"
            style={{ marginLeft: '25px' }}
          />
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNavAltMarkup"
          aria-controls="navbarNavAltMarkup"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkup">
          <div className="navbar-nav">
            <Link to="/" className="nav-link active">HOME</Link>
            <Link to="/about" className="nav-link active">ABOUT US</Link>
            <Link to="/contact" className="nav-link active">CONTACT</Link>
          </div>
        </div>
        
        <div>
          <button type="button" className="btn btn-light border-dark m-1 custom-btn-sign">SIGN UP</button>
          <button type="button" className="btn btn-primary custom-btn-login">LOGIN</button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
