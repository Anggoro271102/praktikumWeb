import AboutSection from "../component/AboutSection";

const About = () => {
    return(
        <div>
            <AboutSection/>
        </div>
       
    );
};

export default About