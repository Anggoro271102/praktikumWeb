import HobbySection from "../component/HobbySection";

const Hobby = () => {
    return(
        <div>
            <HobbySection/>
        </div>
       
    );
};

export default Hobby