import SkillSection from "../component/SkillSection";


const Skill = () => {
    return(
        <div>
            <SkillSection/>
        </div> 
    );
};

export default Skill